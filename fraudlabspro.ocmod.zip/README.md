#### Installation

1. Login to the OpenCart admin area.

2. Disable and uninstall the existing FraudLabs Pro extension at Extensions > Extensions > Anti-Fraud.

3. Go to Extensions > Installer and upload this ocmod.zip file.

4. Go to Extensions > Extensions > Anti-Fraud > FraudLabs Pro to install and edit the settings of this extension.

5. Select Enabled. Then enter the FraudLabs Pro API key and other settings.

6. Click on the save button to save the new configuration.

7. Done.

##### Support

This extension has been successfully tested for OpenCart version 3.0.x.

For any sugggestion or issues, kindly submit your feedback to support@fraudlabspro.com